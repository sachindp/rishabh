package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.model.SKYCustomers;

import com.cg.service.SkyService;


@Controller
public class WebController {

	@Autowired
	SkyService custservice;
	
	
	
	public WebController() {
		super();
	}

	public WebController(SkyService customerservice) {
		super();
		this.custservice = customerservice;
	}

	public SkyService getCustomerservice() {
		return custservice;
	}

	public void setCustomerservice(SkyService customerservice) {
		this.custservice = customerservice;
	}

	@RequestMapping(value="/")
	public String home(){
		return "homePage";
	}
	
	@RequestMapping(value="/CustReportBycustNum")
	public String CustReportBycustNum(@RequestParam("custNum") String custNum, Model model){
		
				try 
				{
					SKYCustomers cust = custservice.getServiceDetails(custNum);
					model.addAttribute("c", cust);
					return "CustReportBycustNum";
				} 
				catch (Exception e) 
				{
					model.addAttribute("msg", e.getMessage());
					return "myError";
				}
	}
	
	@RequestMapping("/showViewAllCustomer")
	public String showViewAllCustomer(Model model) {

		
	

		try 
		{
			List<SKYCustomers> List = custservice.getCustomerDetails();
			
			model.addAttribute("List", List);
			
			return "CustReport";
		} 
		catch (Exception e) 
		{
			model.addAttribute("msg", e.getMessage());
			
			return "myError";
		}
		
	}
}
