package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.SkyDAO;
import com.cg.model.SKYCustomers;

@Service
public class SkySeviceImpl implements SkyService{

	@Autowired
	SkyDAO skyDao;
	
	

	//------------------------ Sky Star Cable --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getCustomerDetails
	 - Creation Date	:	24/11/2017
	 - Description		:	calls dao method getCustomerDetails()
	 ********************************************************************************************************/
	
	@Override
	public List<SKYCustomers> getCustomerDetails() {
		
		return skyDao.getCustomerDetails();
	}
	

	//------------------------ Sky Star Cable --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getServiceDetails
	 - Creation Date	:	24/11/2017
	 - Description		:	calls dao method getServicerDetails()
	 ********************************************************************************************************/

	@Override
	public SKYCustomers getServiceDetails(String custNum) {
		
		return skyDao.getServiceDetails(custNum);
	}

}
