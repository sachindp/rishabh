package com.cg.dao;

import java.util.List;

import com.cg.model.SKYCustomers;

public interface SkyDAO {

	public List<SKYCustomers> getCustomerDetails();
	public SKYCustomers getServiceDetails(String custNum);
}
