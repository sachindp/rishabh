package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.model.SKYCustomers;



@Repository
@Transactional
public class SkyDaoImpl implements SkyDAO{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<SKYCustomers> getCustomerDetails() {
		TypedQuery<SKYCustomers> query = entityManager.createQuery("SELECT cust FROM SKYCustomers cust", SKYCustomers.class);
		return query.getResultList();
	}

	@Override
	public SKYCustomers getServiceDetails(String custNum) {
		return entityManager.find(SKYCustomers.class, custNum);
	}

}
