package com.capgemini.pms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.pms.entities.Product;
import com.capgemini.pms.exception.ProductException;



@Repository
public class ProductDAOImpl implements IProductDAO 
{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	
	
	@Override
	public Product removeProduct(int id) throws ProductException
	{
		Product product= null;
		 
		try 
		{
			
			String query1= "select product from Product product where product.id=:pId";	
			TypedQuery<Product> tquery1= entityManager.createQuery(query1, Product.class);			
			tquery1.setParameter("pId", id);
			product=tquery1.getSingleResult();
			
			if(product == null)
				throw new Exception("Product with ID "+ id+ "Does not exist ");
			
			String query2= "delete from Product product where product.id=:pId";
			Query tquery2= entityManager.createQuery(query2);
			tquery2.setParameter("pId", id);
			tquery2.executeUpdate();

			
		} 
		catch (Exception e)
		{
			throw new ProductException(e.getMessage());
		}

		
		
		return product;
	}
	
	
	@Override
	public List<Product> getAllProducts() throws ProductException
	{
		List<Product> products= null;
		
		try
		{
			TypedQuery<Product> tquery= entityManager.createNamedQuery("GetAllProducts", Product.class);
			
			products= tquery.getResultList();
			
			if(products == null || products.isEmpty())
				throw new Exception("No Products to Display");
		}
		catch (Exception e)
		{
			throw new ProductException(e.getMessage());
			
		}
		
		
		return products;
	}
	
	
	
	
}