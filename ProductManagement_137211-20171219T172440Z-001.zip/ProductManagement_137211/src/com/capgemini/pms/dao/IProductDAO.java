package com.capgemini.pms.dao;

import java.util.List;

import com.capgemini.pms.entities.Product;
import com.capgemini.pms.exception.ProductException;

public interface IProductDAO 
{
	public Product removeProduct(int id) throws ProductException;

	public List<Product> getAllProducts() throws ProductException;
	
}
